
package jar.camouflageblocks.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import jar.camouflageblocks.procedures.NotPlaceBlocksProcedure;
import jar.camouflageblocks.procedures.BlocksBreakingProcedure;

public class ChiseledResinBricksCarpetBlock extends Block {
	public ChiseledResinBricksCarpetBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM)
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_break")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_step")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_place")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_hit")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_fall"))))
				.strength(1.5f, 6f).requiresCorrectToolForDrops().noOcclusion().pushReaction(PushReaction.DESTROY).isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return box(0, 0, 0, 16, 1, 16);
	}

	@Override
	public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, BlockPos fromPos, boolean moving) {
		super.neighborChanged(blockstate, world, pos, neighborBlock, fromPos, moving);
		BlocksBreakingProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public void setPlacedBy(Level world, BlockPos pos, BlockState blockstate, LivingEntity entity, ItemStack itemstack) {
		super.setPlacedBy(world, pos, blockstate, entity, itemstack);
		NotPlaceBlocksProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ(), itemstack);
	}
}
