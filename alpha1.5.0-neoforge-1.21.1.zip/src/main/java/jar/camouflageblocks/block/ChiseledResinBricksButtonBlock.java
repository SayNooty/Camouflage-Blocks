
package jar.camouflageblocks.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import jar.camouflageblocks.procedures.PlaySoundResinBricksPlaceProcedure;
import jar.camouflageblocks.procedures.PlaySoundResinBricksClickProcedure;
import jar.camouflageblocks.procedures.PlaySoundResinBricksBreakProcedure;

public class ChiseledResinBricksButtonBlock extends ButtonBlock {
	public ChiseledResinBricksButtonBlock() {
		super(BlockSetType.STONE, 20,
				BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM)
						.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_break")),
								() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_step")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_place")),
								() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_hit")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_fall"))))
						.strength(1.5f, 6f).requiresCorrectToolForDrops().noCollission().noOcclusion().pushReaction(PushReaction.DESTROY).isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
		boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
		PlaySoundResinBricksBreakProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		return retval;
	}

	@Override
	public void wasExploded(Level world, BlockPos pos, Explosion e) {
		super.wasExploded(world, pos, e);
		PlaySoundResinBricksBreakProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public void attack(BlockState blockstate, Level world, BlockPos pos, Player entity) {
		super.attack(blockstate, world, pos, entity);
		PlaySoundResinBricksClickProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public void setPlacedBy(Level world, BlockPos pos, BlockState blockstate, LivingEntity entity, ItemStack itemstack) {
		super.setPlacedBy(world, pos, blockstate, entity, itemstack);
		PlaySoundResinBricksPlaceProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}
