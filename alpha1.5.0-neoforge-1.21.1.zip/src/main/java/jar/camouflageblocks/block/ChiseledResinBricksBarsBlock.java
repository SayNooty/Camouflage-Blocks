
package jar.camouflageblocks.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

public class ChiseledResinBricksBarsBlock extends IronBarsBlock {
	public ChiseledResinBricksBarsBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM)
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_break")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_step")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_place")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_hit")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_fall"))))
				.strength(1.5f, 6f).requiresCorrectToolForDrops().noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}
}
