
package jar.camouflageblocks.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

public class ChiseledResinBricksFlowerPotBlock extends Block {
	public ChiseledResinBricksFlowerPotBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM)
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_break")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_step")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_place")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_hit")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_fall"))))
				.instabreak().noOcclusion().pushReaction(PushReaction.DESTROY).isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.or(box(5, 0, 5, 6, 6, 11), box(10, 0, 5, 11, 6, 11), box(6, 0, 5, 10, 6, 6), box(6, 0, 10, 10, 6, 11), box(6, 0, 6, 10, 4, 10));
	}
}
