
package jar.camouflageblocks.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class ChiseledResinBricksLecternBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public ChiseledResinBricksLecternBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM)
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_break")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_step")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_place")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_hit")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("camouflage_blocks:resin_bricks_fall"))))
				.strength(1.5f, 3f).requiresCorrectToolForDrops().noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(4, 2, 6, 12, 15, 10), box(0, 12, 6.5, 16, 16, 10.3), box(0, 10, 10.3, 16, 14, 15), box(0, 14, 2, 16, 18, 6.5), box(4, 2, 4, 12, 14, 12));
			case NORTH -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(4, 2, 6, 12, 15, 10), box(0, 12, 5.7, 16, 16, 9.5), box(0, 10, 1, 16, 14, 5.7), box(0, 14, 9.5, 16, 18, 14), box(4, 2, 4, 12, 14, 12));
			case EAST -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(6, 2, 4, 10, 15, 12), box(6.5, 12, 0, 10.3, 16, 16), box(10.3, 10, 0, 15, 14, 16), box(2, 14, 0, 6.5, 18, 16), box(4, 2, 4, 12, 14, 12));
			case WEST -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(6, 2, 4, 10, 15, 12), box(5.7, 12, 0, 9.5, 16, 16), box(1, 10, 0, 5.7, 14, 16), box(9.5, 14, 0, 14, 18, 16), box(4, 2, 4, 12, 14, 12));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
